import pandas as pd

def profile(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    summary = pd.DataFrame({
        "dtype": df.dtypes.astype(str),
        "missing_count": df.isna().sum(),
        "missing_pct": df.isna().mean().mul(100).round(2),
        "unique_values": df.nunique(dropna=False),
    })
    return summary.sort_values("missing_pct", ascending=False)

if __name__ == "__main__":
    print("Starter project. Update the path to an approved dataset before running.")
    # summary = profile("data/approved_dataset.csv")
    # print(summary.head(20))
