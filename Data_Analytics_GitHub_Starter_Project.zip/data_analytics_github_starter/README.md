# Data Analytics Strategic Plan – Week 1

This repository supports the Week 1 Data Analytics Strategist internship task.

## Contents
- `README.md` – project overview
- `requirements.txt` – Python dependencies
- `src/analytics_plan_demo.py` – reproducible starter analytics workflow
- `notebooks/` – place internship notebooks here
- `data/` – place approved, non-sensitive datasets here

## Suggested workflow
1. Add an approved dataset.
2. Run the profiling and KPI workflow.
3. Document assumptions and data-quality checks.
4. Build a Power BI dashboard from validated outputs.
5. Commit the report/notebook and update the README with results.

Do not upload confidential, personally identifiable, proprietary, or restricted internship data.
